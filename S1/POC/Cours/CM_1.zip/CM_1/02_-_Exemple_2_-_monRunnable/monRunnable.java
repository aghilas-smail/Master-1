// -*- coding: utf-8 -*-

public class monRunnable implements Runnable {
    public void run()
    {
        for (int i = 1;i<=1000;i++)
            System.out.println(i);
    }
} 
