// -*- coding: utf-8 -*-

public class Compteur extends Thread {
    static volatile int valeur = 0;

    public static void main(String[] args) throws Exception {
        Compteur Premier = new Compteur();
        Compteur Second = new Compteur();
        Premier.start();
        Second.start();
        Premier.join();
        Second.join();
        System.out.println("La valeur finale est " + valeur);
    }

    public void run(){
        for (int i = 1; i <= 10_000; i++) {
            valeur++;
            System.out.println("La valeur courante est " + valeur);
        }
    }
} 

/*
$ java Compteur
La valeur courante est 1
La valeur courante est 0
La valeur courante est 2
La valeur courante est 3
La valeur courante est 4
La valeur courante est 5
La valeur courante est 6
La valeur courante est 8
...
La valeur courante est 19996
La valeur courante est 19997
La valeur courante est 19998
La valeur courante est 19999
La valeur courante est 20000
La valeur finale est 20000
*/


/*
$ java Compteur
La valeur courante est 1
La valeur courante est 0
La valeur courante est 2
La valeur courante est 3
La valeur courante est 4
La valeur courante est 5
La valeur courante est 6
La valeur courante est 8
...
La valeur courante est 19996
La valeur courante est 19997
La valeur courante est 19998
La valeur courante est 19999
La valeur finale est 19999
*/
