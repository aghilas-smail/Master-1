// -*- coding: utf-8 -*-

import java.lang.Thread; 
import java.lang.Math;

import java.util.concurrent.ThreadLocalRandom;
/*
  A random number generator isolated to the current thread. Like the
  global Random generator used by the Math class, a ThreadLocalRandom
  is initialized with an internally generated seed that may not
  otherwise be modified. When applicable, use of ThreadLocalRandom
  rather than shared Random objects in concurrent programs will
  typically encounter much less overhead and contention. Use of
  ThreadLocalRandom is particularly appropriate when multiple tasks
  (for example, each a ForkJoinTask) use random numbers in parallel
  in thread pools.
*/

public class MonteCarlo {
    static volatile int nbThreads = Runtime.getRuntime().availableProcessors() ;
    // A priori, on lance un thread par coeur disponible ;
    
    static volatile int nbTirages = 1_000_000 ; 
    public volatile int tiragesDansLeDisque = 0 ;

    public static void main (String args[]) {
        System.out.println("Il y a selon Java " + nbThreads + " processeurs disponibles.");

        if (args.length>0) {
            try { nbTirages = 1000_000 * Integer.parseInt(args[0]); } 
            catch(NumberFormatException e) { 
                System.err.println 
                    ("Usage : java MonteCarlo <nb de tirages>"); 
                System.exit(1); 
            }
        }

        if (args.length>1) {
            try { nbThreads = Integer.parseInt(args[1]); } 
            catch(NumberFormatException e) { 
                System.err.println 
                    ("Usage : java MonteCarlo <nb de tirages> <nb de threads>"); 
                System.exit(1); 
            }
        }
      

        System.out.print("Mesures avec " + nbThreads + " threads ");
        System.out.println("et " + nbTirages/1_000_000 + " million(s) de tirages.");

        Tirages[] mesTaches = new Tirages[nbThreads] ;
        Thread[] mesThreads = new Thread[nbThreads] ;
        for (int j = 0; j < nbThreads ; j++){
            mesTaches[j] = new Tirages( nbTirages/nbThreads ) ;
            mesThreads[j] = new Thread (mesTaches[j]);
            mesThreads[j].start();
        }

        // Il faut maintenant attendre la fin des calculs
        for(int i=0; i<nbThreads; i++){
            try{ mesThreads[i].join();}
            catch(InterruptedException e){e.printStackTrace();}
        }

        int somme = 0;
        for(int i=0; i<nbThreads; i++){
            somme += mesTaches[i].tiragesDansLeDisque ;
        }
        double resultat = (double) somme / nbTirages ;
        System.out.format("Estimation de Pi/4: %.9f %n", resultat) ;
        double erreur = 100 * Math.abs(resultat-Math.PI/4)/(Math.PI/4) ;
        System.out.format("Pourcentage d'erreur: %.9f %% %n", erreur);
    }
}

class Tirages implements Runnable {
    long nbTirages;
    long tiragesDansLeDisque = 0 ;

    Tirages(long nbTirages){
        this.nbTirages = nbTirages;
    }
    
    public void run(){
        double x, y;
        ThreadLocalRandom aléa = ThreadLocalRandom.current();
        for (long i = 0; i < nbTirages; i++) {
            x = aléa.nextDouble();
            y = aléa.nextDouble();
            if (x * x + y * y <= 1) {
                tiragesDansLeDisque++ ;
            }
        }
    }
}


/*
  $ make
  javac *.java
  $ java MonteCarlo 10
  Il y a selon Java 8 processeurs disponibles.
  Mesures avec 8 threads et 10 million(s) de tirages.
  Estimation de Pi/4: 0,785310200 
  Pourcentage d'erreur: 0,011199848 % 
  $ java MonteCarlo 100
  Il y a selon Java 8 processeurs disponibles.
  Mesures avec 8 threads et 100 million(s) de tirages.
  Estimation de Pi/4: 0,785396220 
  Pourcentage d'erreur: 0,000247441 % 
*/
