// -*- coding: utf-8 -*-

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import java.util.concurrent.ThreadLocalRandom;
/*
  A random number generator isolated to the current thread. Like the
  global Random generator used by the Math class, a ThreadLocalRandom
  is initialized with an internally generated seed that may not
  otherwise be modified. When applicable, use of ThreadLocalRandom
  rather than shared Random objects in concurrent programs will
  typically encounter much less overhead and contention. Use of
  ThreadLocalRandom is particularly appropriate when multiple tasks
  (for example, each a ForkJoinTask) use random numbers in parallel
  in thread pools.
*/




public class MonteCarlo {  
    static int nbThreads = Runtime.getRuntime().availableProcessors() ;
    // A priori, on lance un thread par coeur disponible

    static long nbTirages = 1000_000_000 ;

    public static void main(String[] args)  {
        System.out.println("Il y a selon Java " + nbThreads + " processeurs disponibles.");

        if (args.length > 0) {    
            try { nbTirages = 1_000_000 * Long.parseLong(args[0]); } 
            catch(NumberFormatException nfe) { 
                System.err.println 
                    ("Usage : java MonteCarlo <nb de tirages en millions> ..."); 
                System.exit(1); 
            }
        }

        if (args.length > 1) {    
            try { nbThreads = Integer.parseInt(args[1]); } 
            catch(NumberFormatException nfe) { 
                System.err.println 
                    ("Usage : java MonteCarlo <nb de tirages en millions> <nb de threads>"); 
                System.exit(1); 
            }
        }

        System.out.print("Mesures avec " + nbThreads + " threads ");
        System.out.println("et " + nbTirages/1_000_000 + " million(s) de tirages.");

        // Création du réservoir formé de nbThreads esclaves
        ExecutorService executeur = Executors.newFixedThreadPool(nbThreads) ;
      
        // Remplissage de la liste des tâches
        Tirages[] mesTaches = new Tirages[nbThreads] ;
        for (int j = 0; j < nbThreads ; j++){
            mesTaches[j] = new Tirages( nbTirages/nbThreads ) ;
            executeur.execute(mesTaches[j]);
        }
        executeur.shutdown(); // Il n'y a plus aucune tâche à soumettre
        // Il faut maintenant attendre la fin des calculs
        try{
            while (! executeur.awaitTermination(1, TimeUnit.SECONDS)) {
                System.out.print("#") ;
            }
        } catch (InterruptedException e) {e.printStackTrace();}
        System.out.println() ;

        long tiragesDansLeDisque = 0 ;
        for (int j = 0; j < nbThreads ; j++) {
            tiragesDansLeDisque += mesTaches[j].tiragesDansLeDisque ;
        }
        double resultat = (double) tiragesDansLeDisque / nbTirages ;

        System.out.println("Estimation de Pi/4: " + resultat) ;
        System.out.println("Pourcentage d'erreur: "
                           + 100 * Math.abs(resultat-Math.PI/4)/(Math.PI/4)
                           + " %");
    }
}


class Tirages implements Runnable{
    long nbTirages;
    long tiragesDansLeDisque = 0 ;

    Tirages(long nbTirages){
        this.nbTirages = nbTirages;
    }
    
    public void run(){
        double x, y;
        ThreadLocalRandom aléa = ThreadLocalRandom.current();
        for (long i = 0; i < nbTirages; i++) {
            x = aléa.nextDouble();
            y = aléa.nextDouble();
            if (x * x + y * y <= 1) {
                tiragesDansLeDisque++ ;
            }
        }
    }
}

/*
  $ make
  javac *.java
  $ java MonteCarlo 1000
  Il y a selon Java 8 processeurs disponibles.
  Mesures avec 8 threads et 1000 million(s) de tirages.
  #
  Estimation de Pi/4: 0.785415868
  Pourcentage d'erreur: 0.0022542200092621214 %
  $ java MonteCarlo 10000
  Il y a selon Java 8 processeurs disponibles.
  Mesures avec 8 threads et 10000 million(s) de tirages.
  ############
  Estimation de Pi/4: 0.785394047
  Pourcentage d'erreur: 5.24116001294537E-4 %
  $
*/

    
