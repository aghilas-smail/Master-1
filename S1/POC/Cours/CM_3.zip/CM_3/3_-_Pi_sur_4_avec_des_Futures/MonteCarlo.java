// -*- coding: utf-8 -*-
import java.util.ArrayList;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.*;

import java.util.concurrent.ThreadLocalRandom;
/*
  A random number generator isolated to the current thread. Like the
  global Random generator used by the Math class, a ThreadLocalRandom
  is initialized with an internally generated seed that may not
  otherwise be modified. When applicable, use of ThreadLocalRandom
  rather than shared Random objects in concurrent programs will
  typically encounter much less overhead and contention. Use of
  ThreadLocalRandom is particularly appropriate when multiple tasks
  (for example, each a ForkJoinTask) use random numbers in parallel
  in thread pools.
*/

public class MonteCarlo {  
    static int nbThreads = Runtime.getRuntime().availableProcessors() ;
    // A priori, on lance un thread par coeur disponible

    static long nbTirages = 1_000_000 ;

    public static void main(String[] args) {
        System.out.println("Il y a selon Java " + nbThreads + " processeurs disponibles.");

        if (args.length > 0) {    
            try { nbTirages = 1_000_000 * Long.parseLong(args[0]); } 
            catch(NumberFormatException nfe) { 
                System.err.println 
                    ("Usage : java MonteCarlo <nb de tirages en millions> ..."); 
                System.exit(1); 
            }
        }

        if (args.length > 1) {    
            try { nbThreads = Integer.parseInt(args[1]); } 
            catch(NumberFormatException nfe) { 
                System.err.println 
                    ("Usage : java MonteCarlo <nb de tirages en millions> <nb de threads>"); 
                System.exit(1); 
            }
        }
      
        System.out.print("Mesures avec " + nbThreads + " threads ");
        System.out.println("et " + nbTirages/1_000_000 + " million(s) de tirages.");

        // Création du réservoir formé de nbThreads esclaves
        ExecutorService executeur = Executors.newFixedThreadPool(nbThreads);
        // Remplissage de la liste des tâches      
        ArrayList<Future<Long>> mesPromesses = new ArrayList<Future<Long>>();
        for (int j = 0; j < nbThreads ; j++){
            Tirages tache = new Tirages( nbTirages/nbThreads );
            Future<Long> resultatSoumis = executeur.submit(tache);
            mesPromesses.add(resultatSoumis);
        }

        Future<Long> promesse;
        long tiragesDansLeDisque = 0 ;
        for (int j = 0; j < nbThreads ; j++){	  
            promesse = mesPromesses.get(j);       // Les promesses dans l'ordre
            try {
                tiragesDansLeDisque += promesse.get(); // Bloquant
            } catch(Exception ignore) {}
        }
        double resultat = (double) tiragesDansLeDisque / nbTirages ;

        System.out.println("Estimation de Pi/4: " + resultat) ;
        System.out.println("Pourcentage d'erreur: "
                           + 100 * Math.abs(resultat-Math.PI/4)/(Math.PI/4)
                           + " %");
        executeur.shutdown(); // Il n'y a plus aucune tâche à soumettre
    }
}


class Tirages implements Callable<Long>{
    long nbTirages;
    long tiragesDansLeDisque = 0 ;

    Tirages(long nbTirages){
        this.nbTirages = nbTirages;
    }
    
    public Long call(){
        double x, y;
        ThreadLocalRandom aléa = ThreadLocalRandom.current();
        for (long i = 0; i < nbTirages; i++) {
            x = aléa.nextDouble();
            y = aléa.nextDouble();
            if (x * x + y * y <= 1) {
                tiragesDansLeDisque++ ;
            }
        }
        return tiragesDansLeDisque;
    }
}

/*
  $ make
  javac *.java
  $ java MonteCarlo 
  Il y a selon Java 8 processeurs disponibles.
  Mesures avec 8 threads et 1 million(s) de tirages.
  Estimation de Pi/4: 0.785415488
  Pourcentage d'erreur: 0.0322058369065735164 %
  $ java MonteCarlo 1000 4
  Il y a selon Java 8 processeurs disponibles.
  Mesures avec 4 threads et 1000 million(s) de tirages.
  Estimation de Pi/4: 0.785399091
  Pourcentage d'erreur: 1.1810602507110098E-4 %
  $ 
*/

    
