// -*- coding: utf-8 -*-
import java.util.ArrayList;

import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.*;

import java.util.concurrent.ThreadLocalRandom;
/*
  A random number generator isolated to the current thread. Like the
  global Random generator used by the Math class, a ThreadLocalRandom
  is initialized with an internally generated seed that may not
  otherwise be modified. When applicable, use of ThreadLocalRandom
  rather than shared Random objects in concurrent programs will
  typically encounter much less overhead and contention. Use of
  ThreadLocalRandom is particularly appropriate when multiple tasks
  (for example, each a ForkJoinTask) use random numbers in parallel
  in thread pools.
*/

public class MonteCarlo {  
    static int nbThreads = Runtime.getRuntime().availableProcessors() ;
    // A priori, on lance un thread par coeur disponible

    static long nbTirages = 1_000_000 ;

    public static void main(String[] args) {
        System.out.println("Il y a selon Java " + nbThreads + " processeurs disponibles.");

        if (args.length > 0) {    
            try { nbTirages = 1_000_000 * Long.parseLong(args[0]); } 
            catch(NumberFormatException nfe) { 
                System.err.println 
                    ("Usage : java MonteCarlo <nb de tirages (en millions)> ..."); 
                System.exit(1); 
            }
        }

        if (args.length > 1) {    
            try { nbThreads = Integer.parseInt(args[1]); } 
            catch(NumberFormatException nfe) { 
                System.err.println 
                    ("Usage : java MonteCarlo <nb de tirages> <nb de threads>"); 
                System.exit(1); 
            }
        }
      
        System.out.print("Mesures avec " + nbThreads + " threads ");
        System.out.println("et " + nbTirages/1_000_000 + " million(s) de tirages.");

        // Création du réservoir formé de nbThreads esclaves
        ExecutorService exécuteur = Executors.newFixedThreadPool(nbThreads);
        CompletionService<Long> ecs =
            new ExecutorCompletionService<Long>(exécuteur);
        for (int j = 0; j < nbThreads ; j++) {
            ecs.submit(new Tirages( nbTirages/nbThreads ));
        }
        int tiragesDansLeDisque = 0;
        for (int j = 0; j < nbThreads; j++) {
            try{
                tiragesDansLeDisque += ecs.take().get() ; 
            } catch(Exception ignoree){};
        }      
        double résultat = (double) tiragesDansLeDisque / nbTirages ;

        System.out.println("Estimation de Pi/4: " + résultat) ;
        System.out.println("Pourcentage d'erreur: "
                           + 100 * Math.abs(résultat-Math.PI/4)/(Math.PI/4)
                           + " %");
        exécuteur.shutdown(); // Il n'y a plus aucune tâche à soumettre
    }
}

class Tirages implements Callable<Long>{
    long nbTirages;
    long tiragesDansLeDisque = 0 ;

    Tirages(long nbTirages){
        this.nbTirages = nbTirages;
    }
    
    public Long call(){
        double x, y;
        ThreadLocalRandom aléa = ThreadLocalRandom.current();
        for (long i = 0; i < nbTirages; i++) {
            x = aléa.nextDouble();
            y = aléa.nextDouble();
            if (x * x + y * y <= 1) {
                tiragesDansLeDisque++ ;
            }
        }
        return tiragesDansLeDisque;
    }
}

/*
  $ make
  javac *.java
  $ java MonteCarlo
  Il y a selon Java 8 processeurs disponibles.
  Mesures avec 8 threads et 1 million(s) de tirages.
  Estimation de Pi/4: 0.785342
  Pourcentage d'erreur: 0.007150945859784644 %
  $ java MonteCarlo 1000 4
  Il y a selon Java 8 processeurs disponibles.
  Mesures avec 4 threads et 1000 million(s) de tirages.
  Estimation de Pi/4: 0.78540273
  Pourcentage d'erreur: 5.814378954001918E-4 %
  $ 
*/

    
