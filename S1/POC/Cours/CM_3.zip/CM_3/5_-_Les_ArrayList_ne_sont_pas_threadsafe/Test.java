// -*- coding: utf-8 -*-

import java.util.List;
import java.util.ArrayList;

public class Test { 
    static final int nbProcs = Runtime.getRuntime().availableProcessors();

    public static void main(String[] args) throws InterruptedException {
        final List<Integer> maListe = new ArrayList<Integer>(); 
        final int longueurMaximum = 1_000;
        final int part = longueurMaximum/nbProcs;

        // for(int i=0; i<longueurMaximum; i++) maListe.add(i);
        // maListe.clear();

        System.out.println("Démarrage des "+ nbProcs +" threads.");
        
        for (int k=0; k< nbProcs; k++){
            new Thread () { public void run() {
                for(;;){
                    for(int i=0; i<part; i++) maListe.add(i);
                    for(int i=0; i<part; i++) maListe.remove(0);
                }
            }}.start();
        }
    }
}        

/*
  $ java Test
  Démarrage des 8 threads.
  Exception in thread "Thread-3" java.lang.ArrayIndexOutOfBoundsException: arraycopy: last source index 1235 out of bounds for object array[1234]
  ....at java.base/java.lang.System.arraycopy(Native Method)
  ....at java.base/java.util.ArrayList.fastRemove(ArrayList.java:672)
  ....at java.base/java.util.ArrayList.remove(ArrayList.java:539)
  ....at Test$1.run(Test.java:26)
*/
