// -*- coding: utf-8 -*-

import java.util.List;
import java.util.ArrayList;

public class Test { 
    static final int nbProcs = Runtime.getRuntime().availableProcessors();

    public static void main(String[] args) throws InterruptedException {
        final List<Integer> maListe = new ArrayList<Integer>(); 
        final int longueurMaximum = 1_000;
        final int part = longueurMaximum/nbProcs;

        for(int i=0; i<longueurMaximum; i++) maListe.add(i);
        maListe.clear();

        System.out.println("Démarrage des "+ nbProcs +" threads.");
        
        for (int k=0; k< nbProcs; k++){
            new Thread () { public void run() {
                for(;;){
                    for(int i=0; i<part; i++)
                        synchronized(maListe){maListe.add(i);} ;
                    for(int i=0; i<part; i++)
                        synchronized(maListe){maListe.remove(0);} ;
                }
            }}.start();
        }
    }
}        

/*
  $ java Test
  ^C
*/
