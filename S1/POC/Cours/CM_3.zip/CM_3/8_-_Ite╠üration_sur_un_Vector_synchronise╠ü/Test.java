// -*- coding: utf-8 -*-

import java.util.List;
// import java.util.ArrayList;
import java.util.Vector;
import java.util.Collections;

public class Test { 

    public static void main(String[] args) throws InterruptedException {
        final Vector<Integer> maListe =  new Vector<Integer>(); 
        final int longueurMaximum = 10;
        
        new Thread () { public void run() {
            for(;;){
                for(int i=0; i<longueurMaximum; i++) maListe.add(i);
                maListe.clear();
            }
        }}.start();
        for(;;) {
            // synchronized(maListe)   // Protection nécessaire !
            { 
                for(Integer n:maListe) {
                    Thread.sleep(100);
                    System.out.print(n);
                }
                System.out.println();
            } 
        }
    }
}        

/*
  $ java Test
  Exception in thread "main" java.util.ConcurrentModificationException
  ....at java.base/java.util.Vector$Itr.checkForComodification(Vector.java:1320)
  ....at java.base/java.util.Vector$Itr.next(Vector.java:1276)
  ....at Test.main(Test.java:23)
  ^C
  $
*/
