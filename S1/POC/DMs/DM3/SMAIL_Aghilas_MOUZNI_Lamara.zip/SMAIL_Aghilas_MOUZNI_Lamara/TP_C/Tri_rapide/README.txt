
* La sortie de l'exécution est :


 Tableau initial :  -2386622 -7124559 5017108 -5531768... -5783595 -9327656 5173838 -5773555
 Démarrage du tri rapide séquenciel.
 Tableau trié :  -9999985 -9999973 -9999969 -9999963... 9999939 9999971 9999976 9999984
 obtenu en 76 millisecondes.
 Démarrage du tri rapide parallèle.
 Tableau trié :  -9999985 -9999973 -9999969 -9999963... 9999939 9999971 9999976 9999984
 obtenu en 23 millisecondes.
 gain: 3
 Les tris sont cohérents.


 Caractéristiques de PC :
    - Processeur : 11th Gen Intel(R) Core(TM) i7-11800H @ 2.30GHz.
    - Ram : 16 go
    - 8 coeur.
    - la vitesse d'horloge est de 3,2 GHz.