// -*- coding: utf-8 -*-

import java.util.Arrays;
import java.util.Random ;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class TriRapide {
    static final int taille = 1_000_000 ;                   // Longueur du tableau à trier
    static final int [] tableau = new int[taille] ;         // Le tableau d'entiers à trier 
    static final int borne = 10 * taille ;                  // Valeur maximale dans le tableau
    public static CompletionService<Void> cse;
    static  final AtomicInteger task = new AtomicInteger();

    // methode pour les echange des valeurs du tableaux.
    private static void echangerElements(int[] t, int m, int n) {
        int temp = t[m] ;
        t[m] = t[n] ;
        t[n] = temp ;
    }

    private static int partitionner(int[] t, int début, int fin) {
        int v = t[fin] ;                               // Choix (arbitraire) du pivot : t[fin]
        int place = début ;                            // Place du pivot, à droite des éléments déplacés
        for (int i = début ; i<fin ; i++) {            // Parcours du *reste* du tableau
            if (t[i] < v) {                            // Cette valeur t[i] doit être à droite du pivot
                echangerElements(t, i, place) ;        // On le place à sa place
                place++ ;                              // On met à jour la place du pivot
            }
        }
        echangerElements(t, place, fin) ;              // Placement définitif du pivot
        return place ;
    }

    private static void trierRapidement(int[] t, int debut, int fin) {
        if (debut < fin) {                             // S'il y a un seul élément, il n'y a rien à faire!
            int p = partitionner(t, debut, fin) ;
            trierRapidement(t, debut, p-1) ;
            trierRapidement(t, p+1, fin) ;
        }
    }


    private  static void trieParellel(int[]t, int debut, int fin) {
        // Un if pour verifier si le tableaux n'est pas vide.
        if (debut< fin) {
            int p = partitionner(t, debut, fin) ;
            int L = p - 1 - debut;

            if(p-debut > taille/100){
                task.addAndGet(1);
                cse.submit(() -> {
                            trieParellel(t, debut, p - 1);
                        }, null
                );
            }
            else{
                trierRapidement(t,debut, p -1);
            }
            if(fin-p > taille/100){
                task.addAndGet(1);
                cse.submit(() -> {
                    trieParellel(t, p + 1, fin);
                }, null);
            }
            else{
                trierRapidement(t,p+1, fin);
            }
        }
    }

    private static void trieParallel_1(int[]t, int debut, int fin) {
        ExecutorService executorService = Executors.newFixedThreadPool(4);
        cse = new ExecutorCompletionService<>(executorService);
        task.set(0);
        trieParellel(t, debut, fin);

        while (task.getAndAdd(-1) > 0) {
            try {
                cse.take();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
         executorService.shutdown();
         cse = null;
    }


    private static void afficher(int[] t, int debut, int fin) {
        for (int i = debut ; i <= debut+3 ; i++) {
            System.out.print(" " + t[i]) ;
        }
        System.out.print("...") ;
        for (int i = fin-3 ; i <= fin ; i++) {
            System.out.print(" " + t[i]) ;
        }
        System.out.println() ;
    }

    public static boolean comparer(int t1[], int t2[]){
        if(t1.length == t2.length) {
            for(int i = 0; i < t1.length; i++) {
                if(t1[i] != t2[i]) return false;
            }
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        Random aléa = new Random() ;
        for (int i=0 ; i<taille ; i++) {                          // Remplissage aléatoire du tableau
            tableau[i] = aléa.nextInt(2*borne) - borne ;            
        }
        System.out.print("Tableau initial : ") ;
        afficher(tableau, 0, taille -1) ;                         // Affiche le tableau à trier

        int[] TableauSequentiel = Arrays.copyOf(tableau,tableau.length);
        System.out.println("Démarrage du tri rapide séquenciel.") ;
        long débutDuTri = System.nanoTime();
        trierRapidement(TableauSequentiel, 0, taille -1);
        long finDuTri = System.nanoTime();

        // Tri du tableau

        long duréeDuTri = (finDuTri - débutDuTri) / 1_000_000 ;
        System.out.print("Tableau trié : ") ; 
        afficher(TableauSequentiel, 0, taille -1) ;                         // Affiche le tableau obtenu
        System.out.println("obtenu en " + duréeDuTri + " millisecondes.") ;

        int[] tableauTrieParalell = Arrays.copyOf(tableau, tableau.length);
        System.out.println("Démarrage du tri rapide parallèle.");
        débutDuTri = System.nanoTime();
        trieParallel_1(tableauTrieParalell, 0, taille - 1);
        // Tri du tableau
        finDuTri = System.nanoTime();
        long duréeDuTriParal = (finDuTri - débutDuTri) / 1_000_000;
        System.out.print("Tableau trié : ");
        afficher(tableauTrieParalell, 0, taille - 1);                         // Affiche le tableau obtenu
        System.out.println("obtenu en " + duréeDuTriParal + " millisecondes.");
        System.out.println("gain: " + duréeDuTri / duréeDuTriParal);
        if(comparer(TableauSequentiel, tableauTrieParalell)){
            System.out.println("Les tris sont cohérents.");
        }
    }
}

