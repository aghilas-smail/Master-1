// -*- coding: utf-8 -*-

class Buffer {
  private final int taille;
  private final byte[] buffer;
  private volatile int disponibles = 0;   
  private volatile int prochain = 0;       
  private volatile int premier = 0;        

  Buffer(int taille) {
    this.taille = taille;
    this.buffer = new byte[taille];
  }

  synchronized void déposer(byte b) throws InterruptedException {
    ...
  }
  
  synchronized byte retirer() throws InterruptedException {
    ...
  }
}    
