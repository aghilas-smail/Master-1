// -*- coding: utf-8 -*-

class Consommateur extends Thread {	
    Buffer buffer;    
    byte donnée;
    public Consommateur(Buffer buffer){
        this.buffer = buffer;
    }
    public void run(){
        while (true) { 
            try {
                donnée = buffer.retirer();
                sleep(500);
            } catch(InterruptedException e){break;}
        }
    }
}	
