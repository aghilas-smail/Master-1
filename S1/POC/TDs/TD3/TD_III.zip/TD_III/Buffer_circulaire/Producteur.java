// -*- coding: utf-8 -*-

class Producteur extends Thread {	
    Buffer buffer;    
    byte donnée = 0;
    public Producteur(Buffer buffer){
        this.buffer = buffer;
    }
    public void run(){
        while (true) { 
            donnée = (byte) ThreadLocalRandom.current().nextInt(100);
            try{
                Thread.sleep(1000);
                buffer.déposer(donnée);
                Thread.sleep(2000);
            } catch(InterruptedException e){ break; }
        }
    }
}	
