// -*- coding: utf-8 -*-

class Philosophe extends Thread {	
  static private volatile int disponibles = 5 ;  
  public Philosophe(String nom) {
    this.setName(nom) ;
  }  

  public void prendreDeuxFourchettes() throws InterruptedException {
    if (disponibles < 2) {
      synchronized(this){
        wait() ;
      }
    }
    disponibles = disponibles - 2 ;
  }
  
  public void lacherDeuxFourchettes() {
    disponibles = disponibles + 2 ;
    synchronized(this){
      notifyAll() ;
    }
  }  

  public void run() {
    while (true) {
      try {
        System.out.println("[" + getName() + "] Je pense...") ;
        sleep((int) Math.random()*1000);
        System.out.println("[" + getName() + "] \t Je suis affamé.") ;
        prendreDeuxFourchettes() ;            // Le philosophe prend deux fourchettes
        System.out.println("[" + getName() + "] \t\t Je mange pendant 3s.") ;
        sleep(3000);
        System.out.println("[" + getName() + "] \t\t\t J'ai bien mangé.") ;
        lacherDeuxFourchettes() ;             // Le philosophe rend les deux fourchettes
      } catch (InterruptedException e){ break ; }
    }
  }
  public static void main(String[] argv) {
    String noms [] = {"Socrate", "Aristote",  "Epicure", "Descartes", "Nietzsche"};
    for(int i=0; i<5; i++) new Philosophe(noms[i]).start() ;
  }	
}

/*
  $ java Philosophe
  [Socrate] Je pense...
  [Aristote] Je pense...
  [Nietzsche] Je pense...
  [Epicure] Je pense...
  [Descartes] Je pense...
  [Aristote] 	 Je suis affamé.
  [Nietzsche] 	 Je suis affamé.
  [Socrate] 	 Je suis affamé.
  [Descartes] 	 Je suis affamé.
  [Epicure] 	 Je suis affamé.
  [Nietzsche] 		 Je mange pendant 3s.
  [Aristote] 		 Je mange pendant 3s.
  [Nietzsche] 			 J'ai bien mangé.
  [Aristote] 			 J'ai bien mangé.
  [Nietzsche] Je pense...
  [Aristote] Je pense...
  [Nietzsche] 	 Je suis affamé.
  [Aristote] 	 Je suis affamé.
  [Nietzsche] 		 Je mange pendant 3s.
  [Aristote] 		 Je mange pendant 3s.
  [Aristote] 			 J'ai bien mangé.
  [Nietzsche] 			 J'ai bien mangé.
  [Aristote] Je pense...
  [Nietzsche] Je pense...
  [Aristote] 	 Je suis affamé.
  [Nietzsche] 	 Je suis affamé.
  [Nietzsche] 		 Je mange pendant 3s.
  [Aristote] 		 Je mange pendant 3s.
  [Aristote] 			 J'ai bien mangé.
  [Aristote] Je pense...
  [Nietzsche] 			 J'ai bien mangé.
  [Aristote] 	 Je suis affamé.
  [Aristote] 		 Je mange pendant 3s.
  [Nietzsche] Je pense...
  [Nietzsche] 	 Je suis affamé.
  [Nietzsche] 		 Je mange pendant 3s.
  [Nietzsche] 			 J'ai bien mangé.
  [Aristote] 			 J'ai bien mangé.
  [Nietzsche] Je pense...
  [Aristote] Je pense...
  [Nietzsche] 	 Je suis affamé.
  [Aristote] 	 Je suis affamé.
  [Aristote] 		 Je mange pendant 3s.
  [Nietzsche] 		 Je mange pendant 3s.
  ^C
  $
*/
