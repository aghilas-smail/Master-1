// -*- coding: utf-8 -*-

import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import java.util.concurrent.atomic.AtomicInteger; 

/*
  C'est samedi soir, l'heure de danser. Les nains dansent avec Blanche-Neige, mais
  elle ne peut danser qu'avec deux nains à la fois: un sémaphore est utilisé pour
  limiter le nombre de nains qui dansent simultanément avec Blanche-Neige
*/


public class SaturdayNightFever {
    
    public static void main(String[] args) throws InterruptedException {
        int nbNains = 7;
        String nom [] = {"Simplet", "Dormeur",  "Atchoum", "Joyeux", "Grincheux", "Prof", "Timide"};
        Nain nain [] = new Nain [nbNains];
        for(int i = 0; i < nbNains; i++) nain[i] = new Nain(nom[i]);
        for(int i = 0; i < nbNains; i++) nain[i].start();
        // for(int i = 0; i < nbNains; i++) nain[i].join();
        // System.out.println("C'est fini.");        
    }
}    

class Nain extends Thread {
    static final MonSémaphore blancheNeige = new MonSémaphore(2);
    static final List<String> danseurs = Collections.synchronizedList(new ArrayList<String>());
    public Nain(String nom) {
        this.setName(nom);
    }
    public void run() {
        Random aléa = new Random() ;
        while(true) {
            try {
                sleep(aléa.nextInt(1000));
            } catch (InterruptedException e) {e.printStackTrace();}
            System.out.println(getName() + " souhaite danser avec Blanche-Neige.");
            blancheNeige.P();        // Puis-je danser avec Blanche-Neige?
            synchronized(danseurs){
                System.out.println(getName() + " danse avec Blanche-Neige.");
                danseurs.add(getName());
                System.out.println(danseurs);
            }
            try {
                sleep(1000);
            } catch (InterruptedException e) {e.printStackTrace();}
            synchronized(danseurs){
                System.out.println(getName() + " va se reposer un peu.");
                danseurs.remove(getName());
                System.out.println(danseurs);
            }
            blancheNeige.V();        // Vas-y, à ton tour!
        }
        // System.out.println(getName() + " a terminé!");
    }	
}

class MonSémaphore {	
    static private final AtomicInteger nbTickets = new AtomicInteger(0); 

    MonSémaphore (int n) {
        if ( n<0 ) throw new IllegalArgumentException("Valeur initiale < 0");    
        nbTickets.set(n);
    }
    
    void P(){	
        while ( nbTickets.get() <1 );
        nbTickets.decrementAndGet();
    }

    void V(){
        nbTickets.incrementAndGet();
    }
}

/* Cette classe Sémaphore est manifestement erronée:
   $ java SaturdayNightFever
   Grincheux souhaite danser avec Blanche-Neige.
   Grincheux danse avec Blanche-Neige.
   [Grincheux]
   Simplet souhaite danser avec Blanche-Neige.
   Simplet danse avec Blanche-Neige.
   [Grincheux, Simplet]
   Dormeur souhaite danser avec Blanche-Neige.
   Joyeux souhaite danser avec Blanche-Neige.
   Timide souhaite danser avec Blanche-Neige.
   Prof souhaite danser avec Blanche-Neige.
   Atchoum souhaite danser avec Blanche-Neige.
   Grincheux va se reposer un peu.
   [Simplet]
   Joyeux danse avec Blanche-Neige.
   [Simplet, Joyeux]
   Dormeur danse avec Blanche-Neige.
   [Simplet, Joyeux, Dormeur]
   Grincheux souhaite danser avec Blanche-Neige.
   Simplet va se reposer un peu.
   ^C
   $
*/
