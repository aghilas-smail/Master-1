// -*- coding: utf-8 -*-

import java.util.ArrayList;

public class SeptNains {
    public static void main(String[] args) {
        int nbNains = 7;
        String nom [] = {"Simplet", "Dormeur",  "Atchoum", "Joyeux", "Grincheux", "Prof", "Timide"};
        Nain nain [] = new Nain [nbNains];
        for(int i = 0; i < nbNains; i++) nain[i] = new Nain(nom[i]);
        for(int i = 0; i < nbNains; i++) nain[i].start();

        /* Attendre 10 s. avant d'interrompre chaque nain */
        try { Thread.sleep(10_000); } catch (InterruptedException e) {e.printStackTrace();}	

        /* Interrompre chaque nain, un à un */
        for(int i = 0; i < nbNains; i++) {
            nain[i].interrupt();
        }
        
        /* Attendre la terminaison de chaque nain, l'un après l'autre */
        for(int i = 0; i < nbNains; i++){
            try { nain[i].join(); } catch (InterruptedException e) {e.printStackTrace();}	
        }

        /* Afficher le message final */
        System.out.println("Tous les nains ont terminé.");        
    }
}    


class Nain extends Thread {
    private static MonVerrou verrou = new MonVerrou();

    public Nain(String nom) {
        this.setName(nom);
    }

    public void run() {
        while(true) {
            try {
                verrou.verrouiller();
                verrou.verrouiller();
                verrou.verrouiller();
                System.out.println(getName() + " accède à Blanche-Neige.");
                sleep(1000);
                System.out.println(getName() + " quitte Blanche-Neige.");
                verrou.déverrouiller();
                verrou.déverrouiller();
                verrou.déverrouiller();
                sleep(100);
            } catch (InterruptedException e) { break ;}	
        }
        System.out.println(getName() + " s'en va!");        
    }
}

class MonVerrou {
    private Thread propriétaire = null ;
    private int nbPrises = 0 ;
    
    public synchronized void verrouiller() throws InterruptedException {
        while( propriétaire != null && propriétaire != Thread.currentThread() ) { wait(); }
        propriétaire = Thread.currentThread() ;
        nbPrises++ ;
    }

    public synchronized void déverrouiller() {
        if ( nbPrises > 0 && propriétaire == Thread.currentThread() ) {
            nbPrises-- ;
            if ( nbPrises == 0 ) propriétaire = null ;
            notifyAll();
        }
    }
}

/*
  $ make
  javac *.java
  $ java SeptNains
  Simplet accède à Blanche-Neige.
  Simplet quitte Blanche-Neige.
  Prof accède à Blanche-Neige.
  Prof quitte Blanche-Neige.
  Timide accède à Blanche-Neige.
  Timide quitte Blanche-Neige.
  Simplet accède à Blanche-Neige.
  Simplet quitte Blanche-Neige.
  Prof accède à Blanche-Neige.
  Prof quitte Blanche-Neige.
  Timide accède à Blanche-Neige.
  Timide quitte Blanche-Neige.
  Simplet accède à Blanche-Neige.
  Simplet quitte Blanche-Neige.
  Prof accède à Blanche-Neige.
  Prof quitte Blanche-Neige.
  Timide accède à Blanche-Neige.
  Timide quitte Blanche-Neige.
  Simplet accède à Blanche-Neige.
  Dormeur s'en va!
  Prof s'en va!
  Joyeux s'en va!
  Simplet s'en va!
  Timide s'en va!
  Grincheux s'en va!
  Atchoum s'en va!
  Tous les nains ont terminé.
*/
