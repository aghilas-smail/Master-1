// -*- coding: utf-8 -*-

import java.util.concurrent.ThreadLocalRandom;

class Buffer {
    private final int taille;
    private final byte[] buffer;
    private volatile int disponibles = 0; // Le buffer est vide
    private volatile int prochain = 0;    // Position du prochain dépôt
    private volatile int premier = 0;     // Position du prochain retrait
    
    Buffer(int taille) {
        this.taille = taille;
        this.buffer = new byte[taille];
    }

    synchronized void déposer(byte b) throws InterruptedException {
        while (disponibles == taille) wait(); // Il n'y a plus de place dans le buffer!
        buffer[prochain] = b;
        prochain = (prochain + 1) % taille;   // Nouvelle position du prochain dépôt
        disponibles++;
        afficher();
        notifyAll();
        // notify();
    }
  
    synchronized byte retirer() throws InterruptedException {
        while (disponibles == 0) wait();   // Il n'y a rien à retirer! 
        byte élément = buffer[premier];
        premier = (premier + 1) % taille;  // Nouvelle position du prochain retrait
        disponibles--;        
        afficher();
        notifyAll();
        // notify();
        return élément;
    }

    synchronized public void afficher() {
        StringBuffer sb = new StringBuffer();
        sb.append (" [ ");
        for (int i=0; i<disponibles; i++) {
            sb.append(buffer[(premier + i) % taille] + " ");
        }
        sb.append("] ");
        System.out.println(sb.toString());
    }
    
    public static void main(String[] argv){
        Buffer monBuffer = new Buffer(1);    // Buffer de taille 1
        for(int i=0; i<2; i++) new Producteur(monBuffer).start();
        for(int i=0; i<2; i++) new Consommateur(monBuffer).start();
    }

    static class Consommateur extends Thread {	
        Buffer monBuffer;    
        public Consommateur(Buffer buffer){
            this.monBuffer = buffer;
        }    
        public void run(){
            while (true) { 
                try { Byte donnée = monBuffer.retirer(); }
                catch(InterruptedException e){ break; }
            }
        }
    }
    static class Producteur extends Thread {	
        Buffer monBuffer;    
        public Producteur(Buffer buffer){
            this.monBuffer = buffer;
        }
        public void run(){
            byte donnée = 0;    
            while (true) { 
                donnée = (byte) ThreadLocalRandom.current().nextInt(100);
                try { monBuffer.déposer(donnée); }
                catch(InterruptedException e){ break; }
            }
        }
    }	
}    
	
/*
*/
