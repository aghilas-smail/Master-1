// -*- coding: utf-8 -*-

class Babouin extends Thread{
    private final Côté origine;           // Côté du canyon où apparaît le babouin: EST ou OUEST
    private static final Corde corde = new Corde();  // Corde utilisée par tous les babouins

    Babouin(Côté origine, int i) {        // Constructeur de la classe Babouin
        this.origine = origine;           // Chaque babouin apparaît d'un côté précis du canyon
        if (origine == Côté.EST) setName("E"+i);
        else setName("O"+i);
    }

    public Côté origine() {
        return origine ;
    }
    
    public void run() {
        System.out.println("Le babouin " + getName() + " arrive sur le côté " + origine);
        try {
            corde.saisir();                       // Pour traverser, le babouin saisit la corde
            System.out.println("\t Le babouin " + getName() + " commence à traverser.");
            sleep(5000);                                 // La traversée ne dure que 5 secondes
            System.out.println("\t\t Le babouin " + getName() + " a terminé sa traversée.");
            corde.lâcher();                      // Arrivé de l'autre côté, le babouin lâche la corde
        } catch(InterruptedException e){e.printStackTrace();}
    }

    public static void main(String[] args) { 
        for (int i = 1; i < 20; i++){
            try { Thread.sleep(2000); } catch(InterruptedException e){e.printStackTrace();}	
            if (Math.random() >= 0.5){
                new Babouin(Côté.EST, i).start();          // Création d'un babouin à l'est
            } else {
                new Babouin(Côté.OUEST, i).start();      // Création d'un babouin à l'ouest
            }
        } // Une vingtaine de babouins sont répartis sur les deux côtés du canyon
    }
}


enum Côté { EST, OUEST }                  // Le canyon possède un côté EST et un côté OUEST


class Corde {
    private int nbBabouins = 0;  // C'est le nombre de babouins sur la corde
    private Côté sens = null;    // C'est le côté d'origine des babouins sur la corde    
    public synchronized void saisir(){
        Babouin courant = (Babouin) Thread.currentThread() ;
        Côté origine = courant.origine() ;
        while (nbBabouins >= 5 || ( nbBabouins > 0 && sens != origine)) {
            try { wait(); } catch(InterruptedException e) {e.printStackTrace();}
        }
        nbBabouins += 1;
        sens=origine;
    }
    public synchronized void lâcher(){
        nbBabouins -= 1 ;
        notifyAll();
    }
}

/*
  $ java Babouin.java
  Le babouin E1 arrive sur le côté EST
  .... Le babouin E1 commence à traverser.
  Le babouin E2 arrive sur le côté EST
  .... Le babouin E2 commence à traverser.
  Le babouin E3 arrive sur le côté EST
  .... Le babouin E3 commence à traverser.
  ........ Le babouin E1 a terminé sa traversée.
  Le babouin E4 arrive sur le côté EST
  .... Le babouin E4 commence à traverser.
  ........ Le babouin E2 a terminé sa traversée.
  Le babouin O5 arrive sur le côté OUEST
  ........ Le babouin E3 a terminé sa traversée.
  Le babouin O6 arrive sur le côté OUEST
  ........ Le babouin E4 a terminé sa traversée.
  .... Le babouin O5 commence à traverser.
  .... Le babouin O6 commence à traverser.
  Le babouin O7 arrive sur le côté OUEST
  .... Le babouin O7 commence à traverser.
  Le babouin O8 arrive sur le côté OUEST
  .... Le babouin O8 commence à traverser.
  ........ Le babouin O5 a terminé sa traversée.
  ........ Le babouin O6 a terminé sa traversée.
  Le babouin O9 arrive sur le côté OUEST
  .... Le babouin O9 commence à traverser.
  ........ Le babouin O7 a terminé sa traversée.
  Le babouin O10 arrive sur le côté OUEST
  .... Le babouin O10 commence à traverser.
  ........ Le babouin O8 a terminé sa traversée.
  Le babouin E11 arrive sur le côté EST
  ........ Le babouin O9 a terminé sa traversée.
  Le babouin E12 arrive sur le côté EST
  ........ Le babouin O10 a terminé sa traversée.
  .... Le babouin E11 commence à traverser.
  .... Le babouin E12 commence à traverser.
  Le babouin E13 arrive sur le côté EST
  .... Le babouin E13 commence à traverser.
  Le babouin E14 arrive sur le côté EST
  .... Le babouin E14 commence à traverser.
  ........ Le babouin E12 a terminé sa traversée.
  ........ Le babouin E11 a terminé sa traversée.
  Le babouin E15 arrive sur le côté EST
  .... Le babouin E15 commence à traverser.
  ........ Le babouin E13 a terminé sa traversée.
  Le babouin E16 arrive sur le côté EST
  .... Le babouin E16 commence à traverser.
  ........ Le babouin E14 a terminé sa traversée.
  Le babouin O17 arrive sur le côté OUEST
  ........ Le babouin E15 a terminé sa traversée.
  Le babouin E18 arrive sur le côté EST
  .... Le babouin E18 commence à traverser.
  ........ Le babouin E16 a terminé sa traversée.
  Le babouin E19 arrive sur le côté EST
  .... Le babouin E19 commence à traverser.
  ........ Le babouin E18 a terminé sa traversée.
  ........ Le babouin E19 a terminé sa traversée.
  .... Le babouin O17 commence à traverser.
  ........ Le babouin O17 a terminé sa traversée.
*/
